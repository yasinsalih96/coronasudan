#
java -cp lib/Ab.jar Main bot=coronasudan action=chat trace=false



